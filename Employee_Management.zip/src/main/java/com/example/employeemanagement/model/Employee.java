package com.example.employeemanagement.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="employee")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int employeeNo;
	@Column
	private String name;
	@Column
	private String department;
	
	public Employee () {
		
	}
	
	public Employee(int employeeNo, String name, float attendance, String department) {
		super();
		this.employeeNo = employeeNo;
		this.name = name;
		this.department = department;
	}

	public int getEmployeeNo() {
		return employeeNo;
	}
	public void setEmployeeNo(int employeeNo) {
		this.employeeNo = employeeNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Employee [employeeNo=" + employeeNo + ", name=" + name + ",  department="+ department + "]";
	}
	
	
	public String getBranch() {
		return department;
	}
	public void setBranch(String department) {
		this.department = department;
	}

	
}
