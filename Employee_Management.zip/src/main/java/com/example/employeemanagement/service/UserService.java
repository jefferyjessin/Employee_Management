package com.example.employeemanagement.service;

import com.example.employeemanagement.model.User;
import com.example.employeemanagement.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public User registerUser(User user) {
        return userRepository.save(user);
    }

    
    public Optional<User> findByUsername(String username) {
        return Optional.ofNullable(userRepository.findByUsername(username));
    }

    
    public boolean authenticate(String username, String password) {
        Optional<User> userOpt = Optional.ofNullable(userRepository.findByUsername(username));

        if (userOpt.isPresent()) {
            User user = userOpt.get();
            /*Compare plain text password directly*/
            return user.getPassword().equals(password);
        }

        return false;
    }
}
